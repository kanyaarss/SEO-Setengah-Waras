const Redis = require('redis');
const axios = require('axios');
const { chromium } = require('playwright-core');
const UserAgent = require('user-agents');

class NodeJSWorker {
    constructor() {
        this.redis = null;
        this.browser = null;
        this.isRunning = false;
        this.config = this.loadConfig();
        this.processingCount = 0;
        this.maxConcurrent = 5;
    }

    loadConfig() {
        return {
            redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
            redisQueue: process.env.REDIS_QUEUE || 'url_queue',
            redisErrorQueue: process.env.REDIS_ERROR_QUEUE || 'backlynx:queue:error',
            redisResultQueue: process.env.REDIS_RESULT_QUEUE || 'result_queue',
            goHost: process.env.GO_HOST || 'go-orchestrator',
            goPort: process.env.GO_PORT || '8080',
            pythonHost: process.env.PYTHON_HOST || 'python-ai',
            pythonPort: process.env.PYTHON_PORT || '5000',
            headless: process.env.NODE_HEADLESS === 'true',
            maxConcurrent: parseInt(process.env.MAX_CONCURRENT_URLS) || 5
        };
    }

    async initialize() {
        try {
            // Initialize Redis
            this.redis = Redis.createClient({ url: this.config.redisUrl });
            await this.redis.connect();
            console.log('Connected to Redis');

            // Initialize Playwright browser
            this.browser = await chromium.launch({
                headless: this.config.headless,
                executablePath: '/usr/bin/chromium-browser',
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-accelerated-2d-canvas',
                    '--no-first-run',
                    '--no-zygote',
                    '--disable-gpu',
                    '--disable-extensions',
                    '--disable-background-timer-throttling',
                    '--disable-renderer-backgrounding',
                    '--disable-backgrounding-occluded-windows',
                    '--disable-features=TranslateUI',
                    '--disable-ipc-flooding-protection'
                ]
            });
            console.log('Browser initialized successfully');
            
            console.log('NodeJS Worker initialized successfully');
        } catch (error) {
            console.error('Failed to initialize NodeJS Worker:', error);
            throw error;
        }
    }

    async start() {
        if (this.isRunning) {
            console.log('Worker is already running');
            return;
        }

        try {
            await this.initialize();
            this.isRunning = true;
            this.maxConcurrent = this.config.maxConcurrent;
            console.log(`NodeJS Worker started with max ${this.maxConcurrent} concurrent tasks`);
            
            // Start queue processing
            this.startQueueProcessor();
            
            // Start health check
            this.startHealthCheck();
        } catch (error) {
            console.error('Failed to start NodeJS Worker:', error);
            throw error;
        }
    }

    async startQueueProcessor() {
        console.log('Starting queue processor...');
        
        while (this.isRunning) {
            try {
                // Check if we can process more tasks
                if (this.processingCount >= this.maxConcurrent) {
                    await this.sleep(1000);
                    continue;
                }

                // Get task from queue (blocking with timeout)
                const taskData = await this.redis.blPop(this.config.redisQueue, 5);
                
                if (taskData && taskData.element) {
                    try {
                        // Validate and parse JSON data
                        const rawElement = typeof taskData.element === 'string'
                            ? taskData.element
                            : taskData.element.toString('utf8');
                        const trimmedElement = rawElement.trim();

                        if (!trimmedElement) {
                            console.warn('Received empty or invalid task data, skipping...');
                            continue;
                        }
                        
                        const task = JSON.parse(trimmedElement);
                        if (task && task.target_domain && !task.targetDomain) {
                            task.targetDomain = task.target_domain;
                        }
                        
                        // Validate required task fields
                        if (!task || !task.url || !task.anchor || !task.targetDomain) {
                            console.warn('Invalid task structure, missing required fields:', task);
                            continue;
                        }
                        
                        this.processingCount++;
                        console.log(`Processing task: ${task.url} (concurrent: ${this.processingCount})`);
                        
                        // Process task asynchronously
                        this.processTask(task).catch(error => {
                            console.error(`Error processing task ${task.url}:`, error);
                        }).finally(() => {
                            this.processingCount--;
                        });
                    } catch (parseError) {
                        console.error('JSON parse error:', parseError.message);
                        console.error('Raw data received:', taskData.element);
                        // Move invalid data to error queue for debugging
                        try {
                            await this.redis.lPush(this.config.redisErrorQueue, taskData.element);
                        } catch (redisError) {
                            console.error('Failed to move invalid data to error queue:', redisError.message);
                        }
                    }
                }
            } catch (error) {
                console.error('Queue processor error:', error);
                await this.sleep(5000); // Wait before retrying
            }
        }
    }

    async processTask(task) {
        const startTime = Date.now();
        let result = {
            url: task.url,
            anchor: task.anchor,
            targetDomain: task.targetDomain,
            status: 'failed',
            responseTime: 0,
            error: null,
            timestamp: new Date().toISOString()
        };

        try {
            console.log(`Starting browser automation for: ${task.url}`);
            
            const page = await this.browser.newPage();
            
            // Set random user agent
            const userAgent = new UserAgent();
            await page.setUserAgent(userAgent.toString());
            
            // Set viewport
            await page.setViewportSize({ width: 1366, height: 768 });
            
            // Navigate to URL
            await page.goto(task.url, { 
                waitUntil: 'networkidle',
                timeout: 30000 
            });
            
            // Wait for page to load
            await page.waitForTimeout(2000);
            
            // Try to find and fill forms or inject backlink
            const injected = await this.injectBacklink(page, task);
            
            if (injected) {
                result.status = 'success';
                console.log(`Successfully injected backlink into: ${task.url}`);
            } else {
                result.status = 'failed';
                result.error = 'No suitable injection point found';
            }
            
            await page.close();
            
        } catch (error) {
            result.error = error.message;
            console.error(`Failed to process ${task.url}:`, error.message);
        }
        
        result.responseTime = Date.now() - startTime;
        
        // Send result back to Go orchestrator
        await this.sendResult(result);
        
        console.log(`Task completed: ${task.url} - ${result.status} (${result.responseTime}ms)`);
    }

    async injectBacklink(page, task) {
        try {
            // Try multiple injection strategies
            
            // Strategy 1: Look for comment forms
            const commentSelectors = [
                'textarea[name="comment"]',
                'textarea[name="message"]',
                'textarea[name="content"]',
                'textarea[id="comment"]',
                'textarea[id="message"]'
            ];
            
            for (const selector of commentSelectors) {
                try {
                    await page.waitForSelector(selector, { timeout: 5000 });
                    
                    // Create backlink content
                    const backlinkContent = `<a href="${task.targetDomain}">${task.anchor}</a> Great content!`;
                    
                    await page.fill(selector, backlinkContent);
                    
                    // Look for submit button
                    const submitSelectors = [
                        'input[type="submit"]',
                        'button[type="submit"]',
                        'input[name="submit"]',
                        'button[name="submit"]'
                    ];
                    
                    for (const submitSelector of submitSelectors) {
                        try {
                            await page.click(submitSelector);
                            await page.waitForTimeout(3000);
                            return true;
                        } catch (e) {
                            continue;
                        }
                    }
                } catch (e) {
                    continue;
                }
            }
            
            // Strategy 2: Look for contact forms
            const contactSelectors = [
                'textarea[name="message"]',
                'textarea[name="inquiry"]',
                'textarea[id="message"]'
            ];
            
            for (const selector of contactSelectors) {
                try {
                    await page.waitForSelector(selector, { timeout: 5000 });
                    
                    const message = `Hi, I wanted to share this useful resource: <a href="${task.targetDomain}">${task.anchor}</a>`;
                    
                    await page.fill(selector, message);
                    
                    const submitBtn = await page.$('input[type="submit"], button[type="submit"]');
                    if (submitBtn) {
                        await submitBtn.click();
                        await page.waitForTimeout(3000);
                        return true;
                    }
                } catch (e) {
                    continue;
                }
            }
            
            return false;
            
        } catch (error) {
            console.error('Backlink injection error:', error);
            return false;
        }
    }

    async sendResult(result) {
        try {
            if (this.redis) {
                await this.redis.lPush(this.config.redisResultQueue, JSON.stringify(result));
                return;
            }

            const response = await axios.post(
                `http://${this.config.goHost}:${this.config.goPort}/api/v1/result`,
                result,
                { timeout: 10000 }
            );
            return response.data;
        } catch (error) {
            console.error('Failed to send result:', error.message);
        }
    }

    async startHealthCheck() {
        setInterval(async () => {
            try {
                await this.redis.ping();
                console.log(`Health check passed - Processing: ${this.processingCount}/${this.maxConcurrent}`);
            } catch (error) {
                console.error('Health check failed:', error);
            }
        }, 30000);
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async stop() {
        this.isRunning = false;
        
        if (this.browser) {
            await this.browser.close();
        }
        
        if (this.redis) {
            await this.redis.disconnect();
        }
        
        console.log('NodeJS Worker stopped');
    }
}

// Start the worker
const worker = new NodeJSWorker();

worker.start().catch(console.error);

// Graceful shutdown
process.on('SIGINT', async () => {
    console.log('Received SIGINT, shutting down gracefully...');
    await worker.stop();
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log('Received SIGTERM, shutting down gracefully...');
    await worker.stop();
    process.exit(0);
});
