const Redis = require('redis');
const axios = require('axios');

class NodeJSWorker {
    constructor() {
        this.redis = null;
        this.isRunning = false;
        this.config = this.loadConfig();
    }

    loadConfig() {
        return {
            redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
            goHost: process.env.GO_HOST || 'go-orchestrator',
            goPort: process.env.GO_PORT || '8080',
            pythonHost: process.env.PYTHON_HOST || 'python-ai',
            pythonPort: process.env.PYTHON_PORT || '5000'
        };
    }

    async initialize() {
        try {
            // Initialize Redis
            this.redis = Redis.createClient({ url: this.config.redisUrl });
            await this.redis.connect();
            console.log('Connected to Redis');
            
            console.log('NodeJS Worker initialized successfully (simplified mode)');
        } catch (error) {
            console.error('Failed to initialize NodeJS Worker:', error);
            throw error;
        }
    }

    async start() {
        if (this.isRunning) {
            console.log('Worker is already running');
            return;
        }

        try {
            await this.initialize();
            this.isRunning = true;
            console.log('NodeJS Worker started successfully (simplified mode)');
            
            // Start simple health check loop
            this.startHealthCheck();
        } catch (error) {
            console.error('Failed to start NodeJS Worker:', error);
            throw error;
        }
    }

    async startHealthCheck() {
        setInterval(async () => {
            try {
                // Simple health check - ping Redis
                await this.redis.ping();
                console.log('Health check passed');
            } catch (error) {
                console.error('Health check failed:', error);
            }
        }, 30000); // Every 30 seconds
    }

    async stop() {
        this.isRunning = false;
        if (this.redis) {
            await this.redis.disconnect();
        }
        console.log('NodeJS Worker stopped');
    }
}

// Start the worker
const worker = new NodeJSWorker();

worker.start().catch(console.error);

// Graceful shutdown
process.on('SIGINT', async () => {
    console.log('Received SIGINT, shutting down gracefully...');
    await worker.stop();
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log('Received SIGTERM, shutting down gracefully...');
    await worker.stop();
    process.exit(0);
});
